#include <stdio.h>
#include <syscall.h>

int
main(int argc, const char* argv[])
{
  int i, j, op, end;
  char *s;
  s = argv[1];
  op = 0;
  while (*s)
  {
    op = op * 10 + *s - 48;
    s++;
  }
  s = argv[2];
  end = 0;
  while (*s)
  {
    end = end * 10 + *s - 48;
    s++;
  }
  for (i = 1; i <= op; i++)
  {
    for (j = 1; j <= end; j++)
    {
      printf ("{%d, %d}", i, j);
      if ((i == op) && (j == end))
        printf (".\n");
      else
        printf (", ");
    }
  }
  return EXIT_SUCCESS;
}
