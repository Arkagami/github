#include <stdio.h>
#include <syscall.h>
#include <string.h>

int
main(int argc UNUSED, const char* argv[] UNUSED)
{
char *com = argv[1], *w1, *w2;
if (argc > 1)
  *w1 = argv[2];
if (argc > 2)
  *w2 = argv[3];

if (!strcmp (com, "help"))
{
  printf ("Enter 'translate help' to print help.\nEnter 'translate find [word]' to translate a word.\nEnter 'translate add [word] [translate]' to add word to translate book.\nEnter 'translate print' to print translate book.\n");
  return EXIT_SUCCESS;
}

if (!strcmp (com, "find"))
{

  return EXIT_SUCCESS;
}

if (!strcmp (com, "add"))
{

  return EXIT_SUCCESS;
}

if (!strcmp (com, "print"))
{
  int book = open ("translate_book");
  if (book == -1)
  {
    printf ("Translate book open failed\n");
    return EXIT_SUCCESS;
  }
  
  return EXIT_SUCCESS;
}

  return EXIT_SUCCESS;
}
