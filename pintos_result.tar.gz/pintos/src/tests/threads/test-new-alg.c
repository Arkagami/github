
/*
  File for 'test-new-alg' task implementation.
*/

#include <stdio.h>
#include "tests/threads/tests.h"
#include "threads/malloc.h"
#include "threads/thread.h"
#include "threads/synch.h"
#include "devices/timer.h"

void
ProcMon ()
{
  struct thread *tr = thread_current ();
  while (tr->cpu_burst > 0)
  {
    msg ("%s", tr->name);
    msg ("%s, PRIORITY = %d, CPU BURST = %d", tr->name, tr->priority, tr->cpu_burst);
    --tr->cpu_burst;
    timer_sleep (1);
  }
}

void
test_new_alg (void) 
{
  thread_set_priority (PRI_MAX);
  create_down ("Proc0", 56, 11, &ProcMon, NULL);
  create_down ("Proc1", 10, 2, &ProcMon, NULL);
  create_down ("Proc2", 58, 3, &ProcMon, NULL);
  create_down ("Proc3", 3, 5, &ProcMon, NULL);
  thread_set_priority (PRI_MIN);
}
