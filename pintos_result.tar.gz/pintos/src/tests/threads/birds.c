/*
  File for 'birds' task implementation.
*/

#include <stdio.h>
#include "tests/threads/tests.h"
#include "threads/malloc.h"
#include "threads/thread.h"
#include "threads/synch.h"
#include "devices/timer.h"

//struct semaphore bird_sleep;
struct condition bird_sleep, this_is_eat;

int dish_count, counts, first;

struct lock bird_work, chick_work, decr;

static void init(unsigned int dish_size UNUSED)
{
  cond_init (&bird_sleep);
  lock_init (&bird_work);
  lock_init (&chick_work);
  cond_init (&this_is_eat);
  first = 0;
}

static void bird(void* arg UNUSED)
{
  msg("bird created.");

  while (1)
  {
    lock_acquire (&bird_work);
    msg ("bird working.");
    int i;
    if (counts == 0)
      counts = dish_count;
    if (first == 0)
      first = 1;
    else
      cond_broadcast (&this_is_eat, &bird_work);
    cond_wait (&bird_sleep, &bird_work);
    lock_release (&bird_work);
  }
}

static void chick(void* arg)
{
  msg("chick %d created.", (int) arg);

  while (1)
  {
    lock_acquire (&bird_work);
    if (counts == 0)
    {
      sema_up (&bird_sleep);
      lock_release (&bird_work);
      continue;
    }
    msg ("chick %d eating.", (int) arg);
    timer_sleep (4);

    --counts;
    if (counts == 0) cond_signal (&bird_sleep, &bird_work);
    cond_wait (&this_is_eat, &bird_work);
    lock_release (&bird_work);
  }
}


void test_birds(unsigned int num_chicks, unsigned int dish_size)
{
  unsigned int i;
  init(dish_size);

  thread_create("bird", PRI_DEFAULT, &bird, NULL);

  dish_count = dish_size;
  counts = dish_size;

  for(i = 0; i < num_chicks; i++)
  {
    char name[32];
    snprintf(name, sizeof(name), "chick_%d", i + 1);
    thread_create(name, PRI_DEFAULT, &chick, (void*) (i+1) );
  }

  timer_msleep(5000);
  pass();
}
