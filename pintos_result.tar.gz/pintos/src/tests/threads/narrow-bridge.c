
/* File for 'narrow_bridge' task implementation.  
   SPbSTU, IBKS, 2017 */

#include <stdio.h>
#include "tests/threads/tests.h"
#include "threads/thread.h"
#include "threads/synch.h"
#include "narrow-bridge.h"

// Called before test. Can initialize some synchronization objects.
void narrow_bridge_init(void)
{
  sema_init (&car_sema[0][0], 0);
  sema_init (&car_sema[0][1], 0);
  sema_init (&car_sema[1][0], 0);
  sema_init (&car_sema[1][1], 0);

  lock_init (&you_dont_go);

  car_count[0][0] = 0;
  car_count[0][1] = 0;
  car_count[1][0] = 0;
  car_count[1][1] = 0;

  count_on_bridge = 0;
  direction_on_bridge = 0;
  directionses = 0;
}

void arrive_bridge(enum car_priority prio, enum car_direction dir)
{
  lock_acquire (&you_dont_go);
  ++car_count[prio][dir];
  if (directionses == 0)
  {
    directionses = -1;
    direction_on_bridge = dir;
  }
  if ((directionses <= 0) && (prio == 1))
  {
    direction_on_bridge = dir;
    directionses = 1;
  }
  lock_release (&you_dont_go);

  lock_acquire (&you_dont_go);
  //sema_up (&car_sema[prio][dir]);
  if (count_on_bridge < 2)
  {
    if (count_on_bridge == 0)
    {
      if ((car_count[1][1] > 1) && (direction_on_bridge == 1))
      {
        count_on_bridge = 2;
        sema_up (&car_sema[1][1]);
        sema_up (&car_sema[1][1]);
      }
      else
      if ((car_count[1][1] == 1) && (direction_on_bridge == 1))
      {
        ++count_on_bridge;
        sema_up (&car_sema[1][1]);
        if (car_count[0][1] > 0)
        {
          ++count_on_bridge;
          sema_up (&car_sema[0][1]);
        }
      }
      if ((car_count[1][0] > 1) && (direction_on_bridge == 0))
      {
        count_on_bridge = 2;
        sema_up (&car_sema[1][0]);
        sema_up (&car_sema[1][0]);
      }
      else
      if ((car_count[1][0] == 1) && (direction_on_bridge == 0))
      {
        ++count_on_bridge;
        sema_up (&car_sema[1][0]);
        if (car_count[0][0] > 0)
        {
          ++count_on_bridge;
          sema_up (&car_sema[0][0]);
        }
      }
      else
      if ((car_count[0][1] > 1) && (direction_on_bridge == 1))
      {
        count_on_bridge = 2;
        sema_up (&car_sema[0][1]);
        sema_up (&car_sema[0][1]);
      }
      else
      if ((car_count[0][1] == 1) && (direction_on_bridge == 1))
      {
        ++count_on_bridge;
        sema_up (&car_sema[0][1]);
      }
      else
      if ((car_count[0][0] > 1) && (direction_on_bridge == 0))
      {
        count_on_bridge = 2;
        sema_up (&car_sema[0][0]);
        sema_up (&car_sema[0][0]);
      }
      else
      if ((car_count[0][0] == 1) && (direction_on_bridge == 0))
      {
        ++count_on_bridge;
        sema_up (&car_sema[0][0]);
      }
    }
    else
    {
      if ((car_count[1][1] > 0) && (direction_on_bridge == 1))
      {
        ++count_on_bridge;
        sema_up (&car_sema[1][1]);
      }
      else
      if ((car_count[1][0] > 0) && (direction_on_bridge == 0))
      {
        ++count_on_bridge;
        sema_up (&car_sema[1][0]);
      }
      else
      if ((car_count[0][1] > 0) && (direction_on_bridge == 1))
      {
        ++count_on_bridge;
        sema_up (&car_sema[0][1]);
      }
      else
      if ((car_count[0][0] > 0) && (direction_on_bridge == 0))// && (car_count[1][1] == 0))
      {
        ++count_on_bridge;
        sema_up (&car_sema[0][0]);
      }
    }
  }
  lock_release (&you_dont_go);

  sema_down (&car_sema[prio][dir]);

  lock_acquire (&you_dont_go);
  --car_count[prio][dir];
  lock_release (&you_dont_go);
}

void exit_bridge(enum car_priority prio, enum car_direction dir)
{
  lock_acquire (&you_dont_go);
  --count_on_bridge;
  if (count_on_bridge == 0)
    direction_on_bridge = (direction_on_bridge + 1) % 2;
  lock_release (&you_dont_go);
}
