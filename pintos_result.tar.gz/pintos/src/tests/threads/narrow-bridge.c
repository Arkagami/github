
/* File for 'narrow_bridge' task implementation.  
   SPbSTU, IBKS, 2017 */

#include <stdio.h>
#include "tests/threads/tests.h"
#include "threads/thread.h"
#include "threads/synch.h"
#include "narrow-bridge.h"

struct semaphore car_sema00, car_sema01, car_sema10, car_sema11;

struct lock you_dont_go;

int car_count[2][2];   // car_prioritycar_direction

int direction_on_bridge, directionses;
int count_on_bridge;

// Called before test. Can initialize some synchronization objects.
void narrow_bridge_init(void)
{
  sema_init (&car_sema00, 0);
  sema_init (&car_sema01, 0);
  sema_init (&car_sema10, 0);
  sema_init (&car_sema11, 0);

  lock_init (&you_dont_go);

  car_count[0][0] = 0;
  car_count[0][1] = 0;
  car_count[1][0] = 0;
  car_count[1][1] = 0;

  count_on_bridge = 0;
  direction_on_bridge = 0;
  directionses = 0;
}

void schedules ()
{
  lock_acquire (&you_dont_go);
  //msg ("car00 = %d, car01 = %d, car10 = %d, car11 = %d || dir = %d, count_on_bridge = %d", car_count[0][0], car_count[0][1], car_count[1][0], car_count[1][1], direction_on_bridge, count_on_bridge);
  if ((count_on_bridge == 0) && (car_count[0][direction_on_bridge] == 0) && (car_count[1][direction_on_bridge] == 0))
  {
    direction_on_bridge = (direction_on_bridge + 1) % 2;
  }
  int counter[2];
  counter[0] = 0;
  counter[1] = 0;
  while (count_on_bridge < 2)
  {
    if ((car_count[1][direction_on_bridge] - counter[1]) > 0)
    {
      counter[1] = counter[1] + 1;
      ++count_on_bridge;
      if (direction_on_bridge == 0)
        sema_up (&car_sema10);
      else
        sema_up (&car_sema11);
      continue;
    }
    if ((car_count[0][direction_on_bridge] - counter[0]) > 0)
    {
      counter[0] = counter[0] + 1;
      ++count_on_bridge;
      if (direction_on_bridge == 0)
        sema_up (&car_sema00);
      else
        sema_up (&car_sema01);
      continue;
    }
    break;
  }
  //msg ("car00 = %d, car01 = %d, car10 = %d, car11 = %d || dir = %d, count_on_bridge = %d-------", car_count[0][0], car_count[0][1], car_count[1][0], car_count[1][1], direction_on_bridge, count_on_bridge);
  lock_release (&you_dont_go);
}

void arrive_bridge(enum car_priority prior, enum car_direction dirr)
{
  lock_acquire (&you_dont_go);
  //msg ("car00 = %d, car01 = %d, car10 = %d, car11 = %d || dir = %d, count_on_bridge = %d - start", car_count[0][0], car_count[0][1], car_count[1][0], car_count[1][1], direction_on_bridge, count_on_bridge);
  int prio, dir;
  if (prior == car_normal)
    prio = 0;
  else
    prio = 1;
  if (dirr == dir_left)
    dir = 0;
  else
    dir = 1;
  car_count[prio][dir] = car_count[prio][dir] + 1;
  if ((count_on_bridge == 0) && (directionses == -1) && (prio == 1))
  {
    directionses = 1;
    direction_on_bridge = dir;
  }
  lock_release (&you_dont_go);

  schedules ();

  if (prio == 0)
  {
    if (dir == 0)
      sema_down (&car_sema00);
    else
      sema_down (&car_sema01);
  }
  else
  {
    if (dir == 0)
      sema_down (&car_sema10);
    else
      sema_down (&car_sema11);
  }

  lock_acquire (&you_dont_go);
  car_count[prio][dir] = car_count[prio][dir] - 1;
  lock_release (&you_dont_go);
}

void exit_bridge(enum car_priority prio UNUSED, enum car_direction dir UNUSED)
{
  lock_acquire (&you_dont_go);
  --count_on_bridge;
  if (count_on_bridge == 0)
  {
    if (car_count[1][direction_on_bridge] == 0)
      if (direction_on_bridge == 0)
        direction_on_bridge = 1;
      else
        direction_on_bridge = 0;
  }
  lock_release (&you_dont_go);

if (count_on_bridge == 0)
  schedules ();
}
