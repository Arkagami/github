#ifndef USERPROG_PROCESS_H
#define USERPROG_PROCESS_H

#include "threads/thread.h"
#include "threads/synch.h"

struct list proc_list;
struct lock sys_lock;

struct sys_proc
{
  int exit_status; //exit status
  tid_t p_tid; //process tid
  tid_t pa_tid; //parent tid
  struct semaphore proc_sema;
  struct file *files[256]; //Opening files
  int load; //Is load success
  struct list_elem elem;
};

//struct sys_proc *proc_tid (tid_t tid);

tid_t process_execute (const char *file_name);
int process_wait (tid_t);
void process_exit (void);
void process_activate (void);

#endif /* userprog/process.h */
