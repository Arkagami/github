#include <stdio.h>
#include <syscall.h>
#include <string.h>

int
main(int argc UNUSED, const char* argv[] UNUSED)
{
char *com = argv[1], *w1 = argv[2], *w2 = argv[3];
long long filesizes;
int book = open ("translate_book");
if (book == -1)
{
  create ("translate_book", 1024);
  book = open ("translate_book");
}
filesizes = filesize (book);
char str[filesizes];
close (book);

if (!strcmp (com, "help"))
{
  printf ("Enter 'translate help' to print help.\nEnter 'translate find [word]' to translate a word.\nEnter 'translate add [word] [translate]' to add word to translate book.\nEnter 'translate print' to print translate book.\n");
  return EXIT_SUCCESS;
}

if (!strcmp (com, "find"))
{
  book = open ("translate_book");
  read (book, str, filesizes);
  close (book);
  int c = 0, ret = 0, pos = 0;
  for (long long i = 0; i < filesizes; i++)
  {
    for (c = 0; c < strlen (w1) + 1; c++)
    {
      if ((w1[c] == '\0') && (str[i+c] == ':'))
      {
        pos = i+c;
        ret = 1;
        break;
      }
      if (w1[c] != str[i+c])
        break;
    }
    if (ret == 1)
    {
      for (i = pos + 1; i < filesizes; i++)
      {
        if (str[i] == '\n')
          break;
        printf ("%c", str[i]);
      }
      printf ("\n");
    }
    else
    {
      printf ("No word in translate book.\n");
    }
  }
  return EXIT_SUCCESS;
}

if (!strcmp (com, "add"))
{
  book = open ("translate_book");
  long long new_len = strlen (str) + strlen (w1) + strlen (w2) + 2;
  read (book, str, filesizes);
  close (book);
  remove ("translate_book");
  if (new_len > filesizes)
    filesizes += 1024;
  book = create ("translate_book", filesizes);
  char new_str[filesizes];
  //strlcat (new_str, str, strlen (str) + 1);
  //strlcat (new_str, w1, strlen (new_str) + strlen (w1) + 1);
  //strlcat (new_str, ":", strlen (new_str) + 2);
  //strlcat (new_str, w2, strlen (new_str) + strlen (w2) + 1);
  //strlcat (new_str, "\n", strlen (new_str) + 1);
  long long i;
  for (i = 0; i < strlen (str); i++)
  {
    new_str[i] = str[i];
  }
  int j = 0;
  for (j = 0; j < strlen (w1); j++)
  {
    new_str[i] = w1[j];
    i++;
  }
  new_str[i++] = ':';
  for (j = 0; j < strlen (w2); j++)
  {
    new_str[i] = w2[j];
    i++;
  }
  new_str[i] = '\n';
  write (book, new_str, filesizes);
  close (book);
  printf ("Write success\n");

  return EXIT_SUCCESS;
}

if (!strcmp (com, "print"))
{
  book = open ("translate_book");
  read (book, str, filesizes);
  printf ("Translations:\n%s", str);
  close (book);
  return EXIT_SUCCESS;
}

  return EXIT_SUCCESS;
}
